package project.SpringDemoBot.service;


import org.scilab.forge.jlatexmath.TeXConstants;
import org.scilab.forge.jlatexmath.TeXFormula;
import org.scilab.forge.jlatexmath.TeXIcon;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.send.SendPhoto;
import org.telegram.telegrambots.meta.api.objects.InputFile;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import project.SpringDemoBot.config.BotConfig;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.LinkedList;
import java.util.Queue;
import java.sql.*;



@Component
public class TelegrammBot extends TelegramLongPollingBot {
    boolean conection = true;

    final BotConfig config;

    public TelegrammBot(BotConfig config) {
        this.config = config;
    }

    @Override
    public String getBotUsername() {
        return config.getBotname();
    }

    @Override
    public String getBotToken() {
        return config.getTokenl();
    }

    @Override
    public void onUpdateReceived(Update update) {

        Message message = update.getMessage();
        if (message == null || !message.hasText()) {
            return;
        }
        String Usertext = message.getText();

        try {
            Connection conn = DriverManager.getConnection("jdbc:sqlite:SQlite/SpringDemoCache.db");
            PreparedStatement CacheCheck = conn.prepareStatement("SELECT image FROM cache WHERE text=?");
            CacheCheck.setString(1, Usertext);
            ResultSet rs = CacheCheck.executeQuery();

            if (conn != null){
                conection = true;
            }

            if (rs.next()) {
                readPicture(Usertext, "imageBLOB.png");

                SendPhoto sendPhoto = new SendPhoto();
                sendPhoto.setChatId(message.getChatId().toString());
                File imagefile = new File("imageBLOB.png");
                sendPhoto.setPhoto(new InputFile(imagefile));
                sendPhoto.setCaption("Результат преобразования формулы LaTeX: " + Usertext);

                try {
                    execute(sendPhoto);
                } catch (TelegramApiException e) {
                    e.printStackTrace();
                }

                if (conn != null) {
                    conn.close();
                }

            } else {
                Latex(Usertext, message);

                //Запись картинки в базу данных

                try (PreparedStatement CACHE = conn.prepareStatement("INSERT  INTO  cache (text, image) VALUES (?, ?);")) {
                    CACHE.setString(1, Usertext);
                    CACHE.setBytes(2, readFile("image.png"));
                    CACHE.executeUpdate();
                } catch (java.sql.SQLException e) {
                    e.printStackTrace();
                    System.out.println("Запись БД не произошла");
                }
            }

                if (conn != null) {
                    conn.close();
                }
            }

         catch (java.sql.SQLException e) {
            conection = false;
            System.out.println(e.getMessage());
        } finally {
            if (conection == false) {
                Latex(Usertext, message);
            }
        }
    }


    public void Latex(String UserMessageText, Message message1) {


        // Попытка преобразования текста в формулу LaTeX
        TeXFormula formula;
        try {
            formula = new TeXFormula(UserMessageText);
        } catch (Exception e) {
            return;
        }

        // Создание объекта TeXIcon с заданным размером и стилем
        TeXIcon icon = formula.createTeXIcon(TeXConstants.STYLE_DISPLAY, 50);

        // Получение изображения из объекта TeXIcon
        BufferedImage image = new BufferedImage(icon.getIconWidth(), icon.getIconHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        g2.setColor(Color.WHITE);
        g2.fillRect(0, 0, icon.getIconWidth(), icon.getIconHeight());
        JLabel jl = new JLabel();
        jl.setForeground(Color.BLACK);
        icon.paintIcon(jl, g2, 0, 0);

        // Отправка изображения пользователю в Telegram

        File imagefile = new File("image.png");

        try {
            ImageIO.write(image, "png", imagefile);
        } catch (IOException e) {
            e.printStackTrace();
        }

        SendPhoto sendPhoto = new SendPhoto();
        sendPhoto.setChatId(message1.getChatId().toString());
        sendPhoto.setPhoto(new InputFile(imagefile));
        sendPhoto.setCaption("Результат преобразования формулы LaTeX: " + UserMessageText);
        try {
            execute(sendPhoto);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }


    private byte[] readFile(String file) {
        ByteArrayOutputStream bos = null;
        try {
            File f = new File(file);
            FileInputStream fis = new FileInputStream(f);
            byte[] buffer = new byte[1024];
            bos = new ByteArrayOutputStream();
            for (int len; (len = fis.read(buffer)) != -1;) {
                bos.write(buffer, 0, len);
            }
        } catch (FileNotFoundException e) {
            System.err.println(e.getMessage());
        } catch (IOException e2) {
            System.err.println(e2.getMessage());
        }
        return bos != null ? bos.toByteArray() : null;
    }


    public void readPicture(String text, String filename) {

        ResultSet rs = null;
        FileOutputStream fos = null;
        PreparedStatement pstmt = null;

        try {
            Connection conn2 = DriverManager.getConnection("jdbc:sqlite:SQlite/SpringDemoCache.db");
            pstmt = conn2.prepareStatement("SELECT image FROM cache WHERE text=?");
            pstmt.setString(1, text);
            rs = pstmt.executeQuery();

            // Запись в файл
            File file = new File(filename);
            fos = new FileOutputStream(file);

            while (rs.next()) {
                InputStream input = rs.getBinaryStream("image");
                byte[] buffer = new byte[1024];
                while (input.read(buffer) > 0) {
                    fos.write(buffer);
                }
            }

            if (conn2 != null) {
                conn2.close();
            }
        } catch (SQLException | IOException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (fos != null) {
                    fos.close();
                }

            } catch (SQLException | IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }


    private void sendMessage(long chatId, String textToSend) throws TelegramApiException {
        SendMessage message = new SendMessage();
        message.setChatId(String.valueOf(chatId));
        message.setText(textToSend);

        try {
            execute(message);
        } catch (TelegramApiException e) {

        }
    }
}
