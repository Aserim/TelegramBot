package project.SpringDemoBot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
